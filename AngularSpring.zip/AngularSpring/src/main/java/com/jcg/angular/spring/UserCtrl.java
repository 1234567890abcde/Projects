package com.jcg.angular.spring;

import org.apache.log4j.Logger;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class UserCtrl {

	private static Logger log = Logger.getLogger(UserCtrl.class);

	// Redirects the user to the index page of the application.
	@RequestMapping(value="/welcome", method = RequestMethod.GET)
	public ModelAndView index() {
		return new ModelAndView("welcome");
	}

	// Sets the dummy user details.
	@RequestMapping(value = "/userlist", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)	
	public @ResponseBody User getDetails() {
		log.info("Fetching the user details .... !");

		User user = new User();
		user.setName("Java Code Geek");
		user.setDepartment("Technical Writing");

		log.info("User details are?= " + user.toString());
		return user;
	}
}