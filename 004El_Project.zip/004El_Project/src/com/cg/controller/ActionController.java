package com.cg.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.bean.Employee;

@WebServlet("/ActionController")
public class ActionController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Employee employee = new Employee();
		employee.setEmpId(101);
		employee.setEmpName("Gunna");
		employee.setEmpSal(19052);
		//request
		request.setAttribute("employee", employee);
		//application
		getServletContext().setAttribute("appEmp", employee);
		//session
		HttpSession session = request.getSession(true);
		session.setAttribute("sessionEmp", employee);
		//cookie
		response.addCookie(new Cookie("savedCookie","JSP Training"));
		//dispatching the request to scope.jsp
		getServletContext().getRequestDispatcher("/scope.jsp").forward(request, response);
		
	}

}
