package com.uas.exception;

public class AdminException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5204212987634324898L;

	public AdminException(String message) {
		super(message);
	}
	
}
