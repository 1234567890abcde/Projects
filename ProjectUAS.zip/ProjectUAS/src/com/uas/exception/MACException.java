package com.uas.exception;

public class MACException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2777250070005933138L;

	public MACException(String message) {
		super(message);
	}

}
