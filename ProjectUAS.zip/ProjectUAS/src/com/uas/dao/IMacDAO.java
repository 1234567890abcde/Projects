package com.uas.dao;

import java.util.List;
import com.uas.bean.ApplicantBean;
import com.uas.bean.UserRole;
import com.uas.exception.MACException;

public interface IMacDAO {
	
	public boolean isAuthenticated(String loginId, String pass, UserRole role) throws MACException;
	
	//view applicant list for specific programs offered
	public List<ApplicantBean> viewListOfApplicants(String programName) throws MACException;
	
	//update status of applicant
	public boolean updateStatus(int applicationId) throws MACException;
}