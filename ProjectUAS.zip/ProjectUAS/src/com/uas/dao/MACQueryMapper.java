package com.uas.dao;

public interface MACQueryMapper {
	public static final String IS_AUTHENTICATED = "";
	public static final String VIEW_APPLICANTS = "";
	public static final String UPDATE_STATUS = "";
}
