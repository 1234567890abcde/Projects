package com.uas.dao;

import java.util.List;
import com.uas.bean.ApplicantBean;
import com.uas.bean.Application_Status;
import com.uas.exception.ApplicantException;

public interface IApplicantDAO {
	public List<Object> viewPrograms() throws ApplicantException;
	public boolean insertApplicant(ApplicantBean applicantBean) throws ApplicantException;
	public Application_Status viewStatus(int applicantId) throws ApplicantException;
}
