package com.capgemini.jsp.dao;

import com.capgemini.jsp.dto.BillDTO;
import com.capgemini.jsp.exception.BillUserException;

public interface IEBillDAO {
	public boolean insert(BillDTO billDTO) throws BillUserException;
	
	public String getCustName(int consumerNo) throws BillUserException;
}
