package com.capgemini.jsp.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.jsp.dto.BillDTO;
import com.capgemini.jsp.exception.BillUserException;
import com.capgemini.jsp.service.EBillServiceImpl;
import com.capgemini.jsp.service.IEBillService;

/**
 * Servlet implementation class EBillServletController
 */
@WebServlet("/EBillServletController")
public class EBillServletController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		HttpSession session = request.getSession();
		ServletContext ctx=getServletContext();
		
		final double FIXED_AMOUNT = 100;
		double netAmount = 0.0;
		double currentReading = Double.parseDouble(request.getParameter("currentReading"));
		double lastReading = Double.parseDouble(request.getParameter("lastReading"));
		
		double unitsConsumed = currentReading - lastReading;
		
		int consumerNo = Integer.parseInt(request.getParameter("consumerNo"));
		
		netAmount = unitsConsumed * 1.15 + FIXED_AMOUNT;
		
		BillDTO billDTO = new BillDTO();
		
		billDTO.setConsumer_num(consumerNo);
		billDTO.setCur_reading(currentReading);
		billDTO.setUnitConsumed(unitsConsumed);
		billDTO.setNetAmount(netAmount);
		session.setAttribute("bills", billDTO);
		IEBillService eBillService = new EBillServiceImpl();
		RequestDispatcher rd =null;
		try {
			String name = eBillService.insert(billDTO);
			session.setAttribute("name", name);
			rd=ctx.getRequestDispatcher("/Bill_Info.jsp");
			rd.forward(request, response);
		} catch (BillUserException e) {
			rd=ctx.getRequestDispatcher("/Error.jsp");
			rd.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
