package com.capgemini.jsp.service;

import com.capgemini.jsp.dto.BillDTO;
import com.capgemini.jsp.exception.BillUserException;

public interface IEBillService {
	public String insert(BillDTO billDTO) throws BillUserException;
}
