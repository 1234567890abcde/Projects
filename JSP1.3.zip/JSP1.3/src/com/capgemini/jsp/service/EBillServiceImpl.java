package com.capgemini.jsp.service;

import com.capgemini.jsp.dao.EBillDAOImpl;
import com.capgemini.jsp.dao.IEBillDAO;
import com.capgemini.jsp.dto.BillDTO;
import com.capgemini.jsp.exception.BillUserException;

public class EBillServiceImpl implements IEBillService {
	
	private IEBillDAO ebillDAO;
	
	public EBillServiceImpl() {
		super();
		ebillDAO = new EBillDAOImpl();
	}

	@Override
	public String insert(BillDTO billDTO) throws BillUserException {
		boolean isInserted = false;
		String name = null; 
		isInserted = ebillDAO.insert(billDTO);
		
		if(isInserted){
			name = ebillDAO.getCustName(billDTO.getConsumer_num());
		}else{
			throw new BillUserException("Record couldn't be inserted");
		}
		return name;
	}

}
