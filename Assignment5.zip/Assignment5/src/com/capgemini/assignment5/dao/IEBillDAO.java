package com.capgemini.assignment5.dao;

import com.capgemini.assignment5.dto.BillDTO;
import com.capgemini.assignment5.exception.BillUserException;

public interface IEBillDAO {
	public boolean insert(BillDTO billDTO) throws BillUserException;
	
	public String getCustName(int consumerNo) throws BillUserException;
}
