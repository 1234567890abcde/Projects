package com.capgemini.assignment5.service;

import com.capgemini.assignment5.dao.EBillDAOImpl;
import com.capgemini.assignment5.dao.IEBillDAO;
import com.capgemini.assignment5.dto.BillDTO;
import com.capgemini.assignment5.exception.BillUserException;

public class EBillServiceImpl implements IEBillService {
	
	private IEBillDAO ebillDAO;
	
	public EBillServiceImpl() {
		super();
		ebillDAO = new EBillDAOImpl();
	}

	@Override
	public String insert(BillDTO billDTO) throws BillUserException {
		boolean isInserted = false;
		String name = null; 
		isInserted = ebillDAO.insert(billDTO);
		
		if(isInserted){
			name = ebillDAO.getCustName(billDTO.getConsumer_num());
		}else{
			throw new BillUserException("Record couldn't be inserted");
		}
		return name;
	}

}
