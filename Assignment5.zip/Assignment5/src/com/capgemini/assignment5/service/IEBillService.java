package com.capgemini.assignment5.service;

import com.capgemini.assignment5.dto.BillDTO;
import com.capgemini.assignment5.exception.BillUserException;

public interface IEBillService {
	public String insert(BillDTO billDTO) throws BillUserException;
}
